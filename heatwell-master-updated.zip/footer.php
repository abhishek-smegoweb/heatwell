<footer class="container-fluid Footer">
  <div class="row">
    <div class="col-xs-12">
        <a class="Footer-link" href="/contacts.php">Contact Us</a>
        <a class="Footer-link" href="/about-heatwell.php">Company Info</a>
        <a class="Footer-link" href="/heating-options/floor-heating-options.php">Our Products</a>
        <a class="Footer-link" href="https://hit.sbt.siemens.com/HIT/fs_global.aspx?lang=en&RC=HQEU&WINX=1259&WINY=828">Siemens Catalogue</a>
        <a class="Footer-link" href="http://www.snowtemp.co.nz/">SnowTemp</a>
        <p class="Footer-copyright">© Copyright Heatwell Ltd. 2017. All rights reserved.</p>
    </div>
  </div>
</footer>

<script async src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
<script async src="/js/jsmain.min.js"></script>