<h2>10 Year Guarantee</h2>
<p><strong>We provide a 10 year gurantee on all of our products and services - excluding thermostat(s)</strong></p>
<p>If you would like to learn more about any of our products or services, or to request a free quote feel free to get in touch with us here:</p>
<a class="btn" href="/contacts.php">Contact Us</a>
